package com.example.isllearningapp

sealed class TeacherScreens(val screen:String) {
    object TeacherHome:TeacherScreens("TeacherHome")
    object TeacherVideo:TeacherScreens("Teacher Video")
    object TeacherExercise:TeacherScreens("Teacher Exercise")
    object TeachersProfile:TeacherScreens("Teachers Profile")
    object TeacherResults:TeacherScreens("Results of Students")


}