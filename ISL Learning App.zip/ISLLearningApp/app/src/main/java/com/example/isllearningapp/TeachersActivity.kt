@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.isllearningapp
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.isllearningapp.ui.theme.GreenJC

class TeachersActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            TeacherDashboard()
        }
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
@Preview
fun TeacherDashboard() {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    var activeIcon by remember { mutableStateOf(Icons.Default.Home) }
    var isBottomSheetVisible by remember { mutableStateOf(false) }
    val bottomSheetState = rememberModalBottomSheetState()
    var context = LocalContext.current.applicationContext

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ISLLearningApp") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Red,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                ),
                navigationIcon = {
                    IconButton(onClick = {
                        // Navigate back to LoginActivity when back button is pressed
                        val intent = Intent(context, LoginActivity::class.java)
                        context.startActivity(intent)
                        (context as? Activity)?.finish() // Close the current activity
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    // Box to position the More button at the top-right corner
                    Box(
                        modifier = Modifier.fillMaxWidth() // Make the Box fill the entire space
                    ) {
                        // Text positioned in the middle of the top bar
                        Text(
                            text = "ISL Learning App", // Modify this text as needed
                            modifier = Modifier.align(Alignment.Center),
                            color = Color.White
                        )

                        IconButton(
                            onClick = {
                                // Navigate to the Help screen when More icon is clicked
                                navController.navigate(Screens.Help.screen)
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd) // Align the "More" button to the top-right
                                .padding(end = 16.dp) // Optional padding to make sure it's not too close to the edge
                        ) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "More")
                        }
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = Color.Red) {
                // Home Icon
                IconButton(onClick = {
                    activeIcon = Icons.Default.Home
                    navController.navigate(TeacherScreens.TeacherHome.screen) { popUpTo(0) }
                },
                    modifier = Modifier.weight(0.2f)
                ) {
                    Icon(Icons.Default.Home, contentDescription = "Home", tint = if (activeIcon == Icons.Default.Home) Color.White else Color.White)
                }

                // Create Exercise Icon
                IconButton(onClick = {
                    activeIcon = Icons.Default.Edit
                    navController.navigate(TeacherScreens.TeacherExercise.screen) { popUpTo(0) }
                },modifier = Modifier.weight(0.2f)) {
                    Icon(Icons.Default.Edit, contentDescription = "Create Exercise", tint = if (activeIcon == Icons.Default.Edit) Color.White else Color.White)
                }

                // Centered Add Button
                Box(modifier = Modifier.weight(0.2f), contentAlignment = Alignment.Center) {
                    FloatingActionButton(onClick = { isBottomSheetVisible = true }, containerColor = Color.White) {
                        Icon(Icons.Default.Add, contentDescription = "Upload Videos", tint = GreenJC)
                    }
                }

                // Date Range Icon with weight to ensure proper alignment
                IconButton(
                    onClick = {
                        activeIcon = Icons.Default.DateRange
                        navController.navigate(TeacherScreens.TeachersProfile.screen) {
                            popUpTo(0)
                        }
                    },
                    modifier = Modifier.weight(0.2f) // Use weight to ensure correct alignment
                ) {
                    Icon(Icons.Default.DateRange, contentDescription = "Date Range", tint = if (activeIcon == Icons.Default.DateRange) Color.White else Color.White)
                }

                // Profile Icon with weight for alignment
                IconButton(onClick = {
                    activeIcon = Icons.Default.Person
                    navController.navigate(TeacherScreens.TeachersProfile.screen) { popUpTo(0) }
                },modifier = Modifier.weight(0.2f)) {
                    Icon(Icons.Default.Person, contentDescription = "Profile", tint = if (activeIcon == Icons.Default.Person) Color.White else Color.White)
                }
            }
        }
    ) {
        NavHost(navController = navController, startDestination = TeacherScreens.TeacherHome.screen) {
            composable(TeacherScreens.TeacherHome.screen) { TeacherHome() }
            composable(TeacherScreens.TeacherVideo.screen) { TeacherVideo() }
            composable(TeacherScreens.TeacherExercise.screen) { TeacherExercise() }
            composable(TeacherScreens.TeachersProfile.screen) { TeacherProfile() }
            composable(TeacherScreens.TeacherResults.screen) { TeacherResults() }
            composable(Screens.SignToSpeech.screen) { SignToSpeech() }
            composable(Screens.Help.screen){ Help()}
        }

        if (isBottomSheetVisible) {
            ModalBottomSheet(
                onDismissRequest = { isBottomSheetVisible = false },
                sheetState = bottomSheetState
            ) {
                Column(modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)) {
                    BottomSheetOption(icon = Icons.Default.AddCircle, label = "Upload Video Lessons") {
                        isBottomSheetVisible = false
                        navController.navigate(TeacherScreens.TeacherVideo.screen) { popUpTo(0) }
                    }
                    BottomSheetOption(icon = Icons.Default.Edit, label = "Create Exercises") {
                        isBottomSheetVisible = false
                        navController.navigate(TeacherScreens.TeacherExercise.screen) { popUpTo(0) }
                    }
                    BottomSheetOption(icon = Icons.Default.CheckCircle, label = "Learn ISL interactively") {
                        isBottomSheetVisible = false
                        navController.navigate(Screens.SignToSpeech.screen) {
                            popUpTo(0) }
                    }
                }
            }
        }
    }
}

@Composable
fun BottomSheetOption(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Icon(icon, contentDescription = null, tint = Color.Blue)
        Text(text = label, color = GreenJC)
    }
}
